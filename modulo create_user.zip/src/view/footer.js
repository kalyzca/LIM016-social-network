const viewFooter = `
  <footer>
    <p>-- SOCIAL NETWORK --</p>
  </footer>
`;

export { viewFooter };
